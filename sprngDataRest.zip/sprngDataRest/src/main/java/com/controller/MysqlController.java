package com.controller;

import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.entities.Marvel_Cinematic_Universe;
import com.google.gson.Gson;
import com.myhiber.HiberUtil;

@RestController
public class MysqlController {
//	@Autowired
//	UserRepo repo;
	HiberUtil ut = new HiberUtil();

	
	public String storeData() {
		String url = "https://subsequent-jealous-jersey.glitch.me/mcu.json";
		RestTemplate rs = new RestTemplate();
		String data = rs.getForObject(url, String.class);

		JSONParser parser = new JSONParser();
		try {
			JSONObject json = (JSONObject) parser.parse(data);

			Set<String> s = json.keySet();
			JSONArray jsa = null;
			for (String st : s) {

				jsa = (JSONArray) json.get(st);
				break;
			}

			for (int i = 0; i < jsa.size(); i++) {

				JSONObject j = (JSONObject) jsa.get(i);

				Marvel_Cinematic_Universe objPojo = new Gson().fromJson(j.toString(), Marvel_Cinematic_Universe.class);
				// System.out.println(objPojo);

				ut.insertdata(objPojo);
				// repo.save(objPojo);

			}

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return data;
	}

	@PutMapping("/update/{id}/{name}")
	public String updateMovie(@PathVariable("id") int id, @PathVariable("name") String name) {
		ut.updateData(id, name);
		
		return "Updated";
		// System.out.println("hello getMapping "+id+" "+name);
		
	}

}
