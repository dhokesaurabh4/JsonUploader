package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.controller.MysqlController;

@SpringBootApplication
public class SprngDataRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprngDataRestApplication.class, args);
		MysqlController ms=new MysqlController();
		ms.storeData();
	}

}
