package com.myhiber;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.entities.Marvel_Cinematic_Universe;

public class HiberUtil {

	
	public void insertdata(Marvel_Cinematic_Universe ob) {
		
		Configuration cgf=new Configuration();
		cgf.configure()	;
		SessionFactory factory=cgf.buildSessionFactory();
		Session s=factory.openSession();
		Transaction tx=s.beginTransaction();
		
		s.save(ob);
		//Project ans=s.load(Project.class,12121);

		//System.out.println(ans.getPname());
		
		tx.commit();
		
		factory.close();
		
	}
	
	public void updateData(int movieId,String ratingName) {
		Configuration cgf=new Configuration();
		cgf.configure()	;
		SessionFactory factory=cgf.buildSessionFactory();
		Session s=factory.openSession();
		Transaction tx=s.beginTransaction();
		Marvel_Cinematic_Universe mcv=(Marvel_Cinematic_Universe)s.get(Marvel_Cinematic_Universe.class, movieId);
		mcv.setRating_name(ratingName);
		s.update(mcv);
		
		
		tx.commit();
		
		factory.close();
	}
}
